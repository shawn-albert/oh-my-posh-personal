Inconsolata-dz for Powerline
============================

:Font creator: Raph Levien
:Source: http://nodnod.net/2009/feb/12/adding-straight-single-and-double-quotes-inconsola/
:Patched by: `Faun <https://github.com/faun>`_
